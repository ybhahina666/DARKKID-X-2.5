package com.darkkidx.papertrading

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.*
import java.text.DecimalFormat

class MainActivity : Activity() {
    private val red = Color.rgb(255,48,48)
    private val bg = Color.rgb(10,10,12)
    private val panel = Color.rgb(25,25,29)
    private val white = Color.WHITE
    private var balance = 10000.0
    private val trades = mutableListOf<String>()
    private lateinit var balanceText: TextView
    private lateinit var statusText: TextView
    private lateinit var priceInput: EditText
    private lateinit var rsiInput: EditText
    private lateinit var tradeList: LinearLayout
    private val fmt = DecimalFormat("#,##0.00")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setBackgroundColor(bg); setPadding(18,18,18,18) }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL }
        scroll.addView(content)
        val title = TextView(this).apply { text="DARKKID X"; textSize=28f; setTextColor(red); gravity=Gravity.CENTER; setTypeface(null,1) }
        content.addView(title)
        content.addView(label("FOREX PAPER TRADING • DEMO ONLY"))
        content.addView(card("SIMULATED ACCOUNT"))
        balanceText = label("Virtual balance: $10,000.00")
        content.addView(balanceText)
        content.addView(label("MANUAL MARKET INPUT"))
        content.addView(label("Current price (example: 2345.60)"))
        priceInput = field("Enter current price")
        content.addView(priceInput)
        content.addView(label("RSI (0–100)"))
        rsiInput = field("Enter RSI value")
        content.addView(rsiInput)
        val analyze = button("ANALYZE CHART INPUT")
        content.addView(analyze)
        statusText = label("Signal: WAITING FOR INPUT")
        content.addView(statusText)
        analyze.setOnClickListener { analyze() }
        content.addView(label("PAPER TRADE CONTROLS"))
        val row = LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }
        val buy = button("SIMULATE BUY")
        val sell = button("SIMULATE SELL")
        row.addView(buy, LinearLayout.LayoutParams(0, dp(50), 1f))
        row.addView(sell, LinearLayout.LayoutParams(0, dp(50), 1f))
        content.addView(row)
        buy.setOnClickListener { addTrade("BUY") }
        sell.setOnClickListener { addTrade("SELL") }
        content.addView(label("SIMULATED TRADE LOG"))
        tradeList = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL }
        content.addView(tradeList)
        content.addView(label("Important: signals are basic educational hints from values you enter, not live market analysis or financial advice. No broker connection, real orders, or real-money trading is included."))
        root.addView(scroll, LinearLayout.LayoutParams(-1,0,1f))
        setContentView(root)
        refreshBalance()
    }
    private fun analyze() {
        val p = priceInput.text.toString().toDoubleOrNull()
        val r = rsiInput.text.toString().toDoubleOrNull()
        if (p == null || p <= 0 || r == null || r !in 0.0..100.0) {
            statusText.text = "Signal: enter a valid price and RSI (0–100)"
            statusText.setTextColor(red); return
        }
        val signal = when {
            r <= 30 -> "POSSIBLE BUY — RSI is oversold"
            r >= 70 -> "POSSIBLE SELL — RSI is overbought"
            else -> "WAIT — RSI is between 30 and 70"
        }
        statusText.text = "Signal: $signal\nPrice entered: $p"
        statusText.setTextColor(if (r <= 30) Color.rgb(70,220,120) else if (r >= 70) red else white)
    }
    private fun addTrade(side: String) {
        val p = priceInput.text.toString().toDoubleOrNull()
        if (p == null || p <= 0) { statusText.text="Enter a valid current price first."; return }
        trades.add(0, "$side @ ${fmt.format(p)} • SIMULATED ONLY")
        val item = label("• " + trades.first())
        item.setTextColor(if (side=="BUY") Color.rgb(70,220,120) else red)
        tradeList.addView(item, 0)
        if (trades.size > 20) { trades.removeAt(trades.lastIndex); tradeList.removeViewAt(tradeList.childCount-1) }
    }
    private fun refreshBalance() { balanceText.text = "Virtual balance: $${fmt.format(balance)}" }
    private fun label(s: String) = TextView(this).apply { text=s; textSize=15f; setTextColor(white); setPadding(4,10,4,10) }
    private fun field(hintText: String) = EditText(this).apply { hint=hintText; setHintTextColor(Color.LTGRAY); setTextColor(white); textSize=16f; setSingleLine(true); setPadding(12,8,12,8); setBackgroundColor(panel) }
    private fun card(s: String) = TextView(this).apply { text=s; textSize=13f; setTextColor(red); setPadding(4,16,4,4) }
    private fun button(s: String) = Button(this).apply { text=s; textSize=12f; setTextColor(white); setBackgroundColor(red); isAllCaps=false }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
