DARKKID X Android project — version 1.0
Scope: manual RSI/price educational signal + simulated BUY/SELL log only.
No live prices, no chart feed, no broker integration, and no real orders.

Build requirement:
- Open this folder in Android Studio on a computer with Android SDK installed.
- Sync Gradle, then Build > Build APK(s).
- The APK normally appears under app/build/outputs/apk/debug/app-debug.apk.

This ZIP is Android source code, NOT a compiled APK. This environment did not have Android SDK/Gradle installed, so it could not compile the APK here. Never enter a broker password or license key into an unknown website.

Cloud build option:
A GitHub Actions workflow is included at .github/workflows/build-apk.yml.
Upload/extract this project into a GitHub repository, ensure Actions are enabled, then open the Actions tab and run "Build DARKKID X APK". When the run succeeds, open the run and download the artifact named DARKKID-X-debug-APK. This is a debug APK for testing, not a Play Store release.
